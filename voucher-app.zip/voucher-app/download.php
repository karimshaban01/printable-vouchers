<?php
/**
 * Serves generated PDFs (or a ZIP of the whole job). Inputs are strictly validated
 * so only files inside storage/jobs/<32-hex-id>/ can ever be read.
 */
$cfg = require __DIR__ . '/config.php';

$job = isset($_GET['job']) ? (string)$_GET['job'] : '';
if (!preg_match('/^[a-f0-9]{32}$/', $job)) {
    http_response_code(400);
    exit('Bad request');
}
$dir = $cfg['storage_dir'] . '/' . $job;
if (!is_dir($dir)) {
    http_response_code(404);
    exit('Not found (files expire after 24 hours).');
}

if (isset($_GET['zip'])) {
    if (!class_exists('ZipArchive')) {
        http_response_code(501);
        exit('ZIP support (php-zip) is not installed on this server.');
    }
    $tmp = tempnam(sys_get_temp_dir(), 'vz');
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::OVERWRITE) !== true) {
        http_response_code(500);
        exit('Cannot create zip');
    }
    foreach (glob($dir . '/*.pdf') as $f) {
        $zip->addFile($f, basename($f));
    }
    $zip->close();
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="voucher_samples.zip"');
    header('Content-Length: ' . filesize($tmp));
    readfile($tmp);
    @unlink($tmp);
    exit;
}

$file = isset($_GET['file']) ? (string)$_GET['file'] : '';
if (!preg_match('/^[A-Za-z0-9_-]+\.pdf$/', $file) || !is_file($dir . '/' . $file)) {
    http_response_code(404);
    exit('Not found');
}
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . filesize($dir . '/' . $file));
header('X-Content-Type-Options: nosniff');
readfile($dir . '/' . $file);
