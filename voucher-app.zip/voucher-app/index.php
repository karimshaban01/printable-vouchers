<?php
/**
 * Wi-Fi Voucher PDF generator: upload one or more voucher CSV files and get one
 * sample voucher PDF per CSV.  PHP 7+, no external libraries.
 */
session_start();
require __DIR__ . '/lib/CsvReader.php';
require __DIR__ . '/lib/VoucherPdf.php';

$cfg = require __DIR__ . '/config.php';

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}

/** Remove old job folders. */
function cleanup_jobs($dir, $ttl)
{
    if (!is_dir($dir)) {
        return;
    }
    foreach (scandir($dir) as $d) {
        if ($d === '.' || $d === '..' || !preg_match('/^[a-f0-9]{32}$/', $d)) {
            continue;
        }
        $p = $dir . '/' . $d;
        if (is_dir($p) && filemtime($p) < time() - $ttl) {
            foreach (glob($p . '/*') as $f) {
                @unlink($f);
            }
            @rmdir($p);
        }
    }
}

/** Turn $_FILES['csv'] (multiple) into a flat list. */
function normalize_files($f)
{
    $out = array();
    if (!isset($f['name']) || !is_array($f['name'])) {
        return $out;
    }
    foreach ($f['name'] as $i => $name) {
        $out[] = array(
            'name'  => $name,
            'tmp'   => $f['tmp_name'][$i],
            'error' => $f['error'][$i],
            'size'  => $f['size'][$i],
        );
    }
    return $out;
}

$results = null;
$job = null;
$formError = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'], (string)$_POST['csrf'])) {
        $formError = 'Session expired, please try again.';
    } else {
        $files = array_filter(normalize_files(isset($_FILES['csv']) ? $_FILES['csv'] : array()),
            function ($f) { return $f['error'] !== UPLOAD_ERR_NO_FILE; });
        if (empty($files)) {
            $formError = 'Please choose at least one .csv file.';
        } elseif (count($files) > $cfg['max_files']) {
            $formError = 'Too many files (max ' . $cfg['max_files'] . ').';
        }
    }

    if ($formError === null) {
        cleanup_jobs($cfg['storage_dir'], $cfg['job_ttl_seconds']);

        $count = isset($_POST['count']) ? (int)$_POST['count'] : $cfg['default_count'];
        if ($count < 1) {
            $count = $cfg['default_count'];
        }
        $count = min($count, $cfg['max_count']);
        $mode = (isset($_POST['mode']) && $_POST['mode'] === 'random') ? 'random' : 'first';

        $opts = array(
            'support_name'   => trim(isset($_POST['support_name']) ? $_POST['support_name'] : $cfg['support_name']),
            'support_phones' => trim(isset($_POST['support_phones']) ? $_POST['support_phones'] : $cfg['support_phones']),
            'logo'           => $cfg['logo'],
        );
        if ($opts['support_name'] === '') {
            $opts['support_name'] = $cfg['support_name'];
        }
        $opts['support_name'] = mb_substr($opts['support_name'], 0, 40);
        $opts['support_phones'] = mb_substr($opts['support_phones'], 0, 60);

        $job = bin2hex(random_bytes(16));
        $jobDir = $cfg['storage_dir'] . '/' . $job;
        if (!is_dir($jobDir) && !mkdir($jobDir, 0775, true)) {
            $formError = 'Cannot create storage folder. Check permissions on storage/jobs.';
        }
    }

    if ($formError === null) {
        $results = array();
        $used = array();
        foreach ($files as $f) {
            $res = array('csv' => $f['name'], 'ok' => false);
            try {
                if ($f['error'] !== UPLOAD_ERR_OK) {
                    throw new Exception('Upload failed (code ' . (int)$f['error'] . ').');
                }
                if (!is_uploaded_file($f['tmp'])) {
                    throw new Exception('Invalid upload.');
                }
                if (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) !== 'csv') {
                    throw new Exception('Not a .csv file.');
                }
                if ($f['size'] > $cfg['max_file_bytes']) {
                    throw new Exception('File is larger than ' . round($cfg['max_file_bytes'] / 1048576) . ' MB.');
                }
                $parsed = CsvReader::read($f['tmp']);
                $codes = $parsed['codes'];
                if (empty($codes)) {
                    throw new Exception('No voucher codes found in this file.');
                }
                $total = count($codes);
                if ($mode === 'random' && $total > $count) {
                    $keys = (array)array_rand($codes, $count);
                    sort($keys);
                    $pick = array();
                    foreach ($keys as $k) {
                        $pick[] = $codes[$k];
                    }
                } else {
                    $pick = array_slice($codes, 0, $count);
                }

                $pdf = VoucherPdf::render($pick, $opts);

                $base = preg_replace('/[^A-Za-z0-9_-]+/', '_', pathinfo($f['name'], PATHINFO_FILENAME));
                $base = trim($base, '_');
                if ($base === '') {
                    $base = 'vouchers';
                }
                $name = $base . '_sample.pdf';
                for ($n = 2; isset($used[$name]); $n++) {
                    $name = $base . '_' . $n . '_sample.pdf';
                }
                $used[$name] = true;
                file_put_contents($jobDir . '/' . $name, $pdf);

                $res['ok'] = true;
                $res['pdf'] = $name;
                $res['total'] = $total;
                $res['used'] = count($pick);
                $res['pages'] = (int)ceil(count($pick) / 10);
                $res['skipped'] = $parsed['skipped'];
                $res['meta'] = array_slice($parsed['meta'], 0, 1);
            } catch (Exception $e) {
                $res['error'] = $e->getMessage();
            }
            $results[] = $res;
        }
    }
}

$canZip = class_exists('ZipArchive');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Wi-Fi Voucher PDF Generator</title>
<style>
  :root { --ink:#1f2d3f; --muted:#5a6b80; --line:#d5dde8; --accent:#1e90ff; --bg:#f3f6fa; --ok:#1d7a46; --err:#b3261e; }
  * { box-sizing: border-box; }
  body { margin:0; font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; color:var(--ink); background:var(--bg); }
  header { background:#212f3e; color:#fff; padding:18px 20px; }
  header h1 { margin:0; font-size:18px; letter-spacing:.04em; }
  header p { margin:2px 0 0; color:#b8c4d3; font-size:13px; }
  main { max-width:720px; margin:24px auto; padding:0 16px; }
  .card { background:#fff; border:1px solid var(--line); border-radius:12px; padding:20px; margin-bottom:18px; }
  label { display:block; font-weight:600; margin:14px 0 4px; }
  label:first-child { margin-top:0; }
  input[type=text], input[type=number], select { width:100%; padding:9px 10px; border:1px solid var(--line); border-radius:8px; font:inherit; }
  input[type=file] { width:100%; padding:18px; border:2px dashed var(--line); border-radius:10px; background:#fafcfe; }
  .row { display:flex; gap:12px; } .row > div { flex:1; }
  .hint { color:var(--muted); font-size:13px; margin:4px 0 0; }
  button, .btn { display:inline-block; background:var(--accent); color:#fff; border:0; padding:11px 20px; border-radius:8px; font:inherit; font-weight:600; cursor:pointer; text-decoration:none; }
  .btn.alt { background:#fff; color:var(--ink); border:1px solid var(--line); }
  .err { color:var(--err); } .okc { color:var(--ok); }
  .alert { background:#fdecea; color:var(--err); padding:10px 14px; border-radius:8px; margin-bottom:16px; }
  table { width:100%; border-collapse:collapse; }
  td, th { padding:10px 6px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }
  th { font-size:12px; text-transform:uppercase; letter-spacing:.05em; color:var(--muted); }
  details { margin-top:14px; } summary { cursor:pointer; font-weight:600; }
</style>
</head>
<body>
<header>
  <h1>WI-FI VOUCHER PDF GENERATOR</h1>
  <p>Upload voucher CSV files and get one sample PDF per file.</p>
</header>
<main>

<?php if ($formError): ?>
  <div class="alert"><?= h($formError) ?></div>
<?php endif; ?>

<?php if ($results !== null): ?>
  <div class="card">
    <h2 style="margin-top:0">Your PDFs</h2>
    <table>
      <tr><th>CSV file</th><th>Result</th><th></th></tr>
      <?php foreach ($results as $r): ?>
        <tr>
          <td><?= h($r['csv']) ?></td>
          <?php if ($r['ok']): ?>
            <td class="okc">
              <?= (int)$r['used'] ?> of <?= (int)$r['total'] ?> codes &middot; <?= (int)$r['pages'] ?> page<?= $r['pages'] > 1 ? 's' : '' ?>
              <?php if ($r['skipped']): ?><br><span class="hint"><?= (int)$r['skipped'] ?> invalid line(s) skipped</span><?php endif; ?>
            </td>
            <td><a class="btn" href="download.php?job=<?= h($job) ?>&amp;file=<?= h(rawurlencode($r['pdf'])) ?>">Download PDF</a></td>
          <?php else: ?>
            <td class="err"><?= h($r['error']) ?></td><td></td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
    </table>
    <p style="margin-bottom:0">
      <?php if ($canZip && count(array_filter($results, function ($r) { return $r['ok']; })) > 1): ?>
        <a class="btn alt" href="download.php?job=<?= h($job) ?>&amp;zip=1">Download all (.zip)</a>
      <?php endif; ?>
      <a class="btn alt" href="index.php">Upload more</a>
    </p>
    <p class="hint">Files are kept for 24 hours and then deleted automatically.</p>
  </div>
<?php else: ?>
  <form class="card" method="post" enctype="multipart/form-data">
    <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">

    <label for="csv">Voucher CSV files</label>
    <input id="csv" type="file" name="csv[]" accept=".csv,text/csv" multiple required>
    <p class="hint">Select one or many .csv files (one code per line; lines starting with # are ignored). Max <?= (int)$cfg['max_files'] ?> files, <?= round($cfg['max_file_bytes'] / 1048576) ?> MB each.</p>

    <div class="row">
      <div>
        <label for="count">Vouchers per PDF</label>
        <input id="count" type="number" name="count" min="1" max="<?= (int)$cfg['max_count'] ?>" value="<?= (int)$cfg['default_count'] ?>">
        <p class="hint">10 = one A4 page.</p>
      </div>
      <div>
        <label for="mode">Which codes</label>
        <select id="mode" name="mode">
          <option value="first">First codes in the file</option>
          <option value="random">Random codes</option>
        </select>
      </div>
    </div>

    <details>
      <summary>Customer-service details on the voucher</summary>
      <label for="sn">Name</label>
      <input id="sn" type="text" name="support_name" maxlength="40" value="<?= h($cfg['support_name']) ?>">
      <label for="sp">Phone number(s)</label>
      <input id="sp" type="text" name="support_phones" maxlength="60" value="<?= h($cfg['support_phones']) ?>">
    </details>

    <p style="margin-bottom:0;margin-top:20px"><button type="submit">Generate PDFs</button></p>
  </form>
<?php endif; ?>

</main>
</body>
</html>
