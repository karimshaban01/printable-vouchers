<?php
/**
 * Reads voucher CSV files: one code per line (first column), '#' lines are
 * comments / roll metadata, blank lines ignored, UTF-8 BOM tolerated.
 */
class CsvReader
{
    /**
     * @return array array('codes' => string[], 'meta' => string[], 'skipped' => int)
     */
    public static function read($path, $maxLen = 100)
    {
        $fh = fopen($path, 'rb');
        if (!$fh) {
            throw new Exception('Cannot open uploaded file.');
        }
        $codes = array();
        $meta = array();
        $skipped = 0;
        $first = true;
        while (($line = fgets($fh)) !== false) {
            if ($first) {
                $line = preg_replace('/^\xEF\xBB\xBF/', '', $line);
                $first = false;
            }
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if ($line[0] === '#') {
                $t = trim(substr($line, 1));
                if ($t !== '') {
                    $meta[] = $t;
                }
                continue;
            }
            $row = str_getcsv($line);
            $code = isset($row[0]) ? trim($row[0]) : '';
            if ($code === '' || strlen($code) > $maxLen || preg_match('/[\x00-\x1f]/', $code)) {
                $skipped++;
                continue;
            }
            $codes[] = $code;
        }
        fclose($fh);
        return array('codes' => $codes, 'meta' => $meta, 'skipped' => $skipped);
    }
}
