<?php
require_once __DIR__ . '/MiniPdf.php';
require_once __DIR__ . '/QrCode.php';

/**
 * Renders Wi-Fi voucher cards, 2 columns x 5 rows per A4 page.
 */
class VoucherPdf
{
    const HEADER = '212f3e';   // matches the logo background
    const INK    = '1f2d3f';
    const MUTED  = '5a6b80';
    const RULE   = 'c7d3e3';

    /**
     * @param string[] $codes
     * @param array    $opts  support_name, support_phones, title, instruction, label, logo
     * @return string  PDF binary
     */
    public static function render(array $codes, array $opts)
    {
        $o = array_merge(array(
            'title'         => 'WI-FI VOUCHER',
            'instruction'   => 'Ingiza kodi ya vocha ili uunganishwe',
            'label'         => 'KODI YA VOCHA',
            'support_name'  => 'KARIM',
            'support_phones' => '',
            'logo'          => null,
        ), $opts);

        $pdf = new MiniPdf(595.28, 841.89);
        $logo = ($o['logo'] && is_file($o['logo'])) ? $pdf->loadJpeg($o['logo']) : null;

        $cols = 2;
        $rows = 5;
        $perPage = $cols * $rows;
        $mx = 28;
        $my = 28;
        $gx = 14;
        $gy = 10;
        $cw = (595.28 - 2 * $mx - ($cols - 1) * $gx) / $cols;
        $ch = (841.89 - 2 * $my - ($rows - 1) * $gy) / $rows;

        if (empty($codes)) {
            $pdf->addPage();
            $pdf->text(297, 420, 'No voucher codes found', 14, 'F2', self::INK, 'C');
            return $pdf->output();
        }

        foreach (array_values($codes) as $i => $code) {
            $slot = $i % $perPage;
            if ($slot === 0) {
                $pdf->addPage();
            }
            $x = $mx + ($slot % $cols) * ($cw + $gx);
            $y = $my + intval($slot / $cols) * ($ch + $gy);
            self::card($pdf, $x, $y, $cw, $ch, $code, $o, $logo);
        }
        return $pdf->output();
    }

    private static function card($pdf, $x, $y, $w, $h, $code, $o, $logo)
    {
        $r = 10;
        $hh = 38; // header height

        // body (white) + header (dark, top corners only)
        $pdf->roundRect($x, $y, $w, $h, $r, $r, $r, $r, 'f', 'ffffff');
        $pdf->roundRect($x, $y, $w, $hh, $r, $r, 0, 0, 'f', self::HEADER);

        if ($logo) {
            $s = $pdf->imageSize($logo);
            $lh = $hh - 2; // inset 1pt so the logo's edge never shows a seam
            $lw = $lh * $s[0] / $s[1];
            $pdf->image($logo, $x + 12, $y + 1, $lw, $lh);
        }
        $pdf->text($x + $w - 14, $y + 24, $o['title'], 11.5, 'F2', 'ffffff', 'R');

        // instruction line + rule
        $pdf->text($x + $w / 2, $y + $hh + 16, $o['instruction'], 7.5, 'F1', self::MUTED, 'C');
        $pdf->line($x + 16, $y + $hh + 24, $x + $w - 16, $y + $hh + 24, self::RULE, 0.6);

        // QR code (left)
        $qs = 64;
        $qx = $x + 18;
        $qy = $y + $hh + 24 + (($h - $hh - 24) - $qs) / 2;
        self::qr($pdf, $code, $qx, $qy, $qs);

        // right column
        $rx0 = $qx + $qs + 12;
        $rx1 = $x + $w - 14;
        $cx = ($rx0 + $rx1) / 2;
        $pdf->text($cx, $y + $hh + 40, $o['label'], 7, 'F1', self::MUTED, 'C');

        $size = 17;
        $maxW = $rx1 - $rx0;
        while ($size > 8 && $pdf->textWidth($code, $size, 'F2') > $maxW) {
            $size -= 0.5;
        }
        $pdf->text($cx, $y + $hh + 60, $code, $size, 'F2', self::INK, 'C');

        $pdf->line($rx0, $y + $hh + 69, $rx1, $y + $hh + 69, self::RULE, 0.6);
        $pdf->text($cx, $y + $hh + 82, 'HUDUMA KWA WATEJA: ' . $o['support_name'], 7, 'F2', self::INK, 'C');
        if ($o['support_phones'] !== '') {
            $pdf->text($cx, $y + $hh + 93, $o['support_phones'], 7, 'F1', self::MUTED, 'C');
        }

        // border on top
        $pdf->roundRect($x, $y, $w, $h, $r, $r, $r, $r, 'S', null, self::HEADER, 0.8);
    }

    private static function qr($pdf, $text, $x, $y, $size)
    {
        $m = QrCode::encode($text);
        $n = count($m);
        $quiet = 0; // card background is white; spacing around it already acts as quiet zone
        $unit = $size / ($n + 2 * $quiet);
        $rects = array();
        for ($r = 0; $r < $n; $r++) {
            $c = 0;
            while ($c < $n) {
                if ($m[$r][$c]) {
                    $start = $c;
                    while ($c < $n && $m[$r][$c]) {
                        $c++;
                    }
                    $rects[] = array($x + ($start + $quiet) * $unit, $y + ($r + $quiet) * $unit,
                        ($c - $start) * $unit + 0.15, $unit + 0.15);
                } else {
                    $c++;
                }
            }
        }
        $pdf->rects($rects, '000000');
    }
}
