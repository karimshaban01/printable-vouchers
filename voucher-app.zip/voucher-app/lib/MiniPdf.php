<?php
/**
 * Tiny dependency-free PDF writer (PHP 5.6+/7.x/8.x).
 * Supports: pages, filled/stroked rectangles (optionally rounded per-corner),
 * lines, Helvetica / Helvetica-Bold text with metrics, JPEG images.
 *
 * Coordinates passed to the drawing methods use a TOP-LEFT origin, in points.
 */
class MiniPdf
{
    private $pageW;
    private $pageH;
    private $pages = array();   // content streams
    private $cur = '';
    private $images = array();  // name => array(w,h,data,channels)
    private $imgCount = 0;

    // Helvetica glyph widths, chars 32..126 (per 1000 units)
    private static $W = array(
        'F1' => array(
            278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,
            556,556,556,556,556,556,556,556,556,556,
            278,278,584,584,584,556,1015,
            667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,
            278,278,278,469,556,333,
            556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,
            334,260,334,584,
        ),
        'F2' => array(
            278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,
            556,556,556,556,556,556,556,556,556,556,
            333,333,584,584,584,611,975,
            722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,
            333,278,333,584,556,333,
            556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,
            389,280,389,584,
        ),
    );

    public function __construct($pageW = 595.28, $pageH = 841.89)
    {
        $this->pageW = $pageW;
        $this->pageH = $pageH;
    }

    // ------------------------------------------------------------ pages / images
    public function addPage()
    {
        if ($this->cur !== '' || !empty($this->pages)) {
            $this->pages[] = $this->cur;
        }
        $this->cur = '';
        $this->started = true;
    }
    private $started = false;

    /** Register a JPEG file, returns image name. */
    public function loadJpeg($path)
    {
        $info = @getimagesize($path);
        if (!$info || $info[2] != IMAGETYPE_JPEG) {
            throw new Exception('Logo must be a JPEG: ' . $path);
        }
        $name = 'Im' . (++$this->imgCount);
        $this->images[$name] = array(
            'w' => $info[0],
            'h' => $info[1],
            'ch' => isset($info['channels']) ? $info['channels'] : 3,
            'data' => file_get_contents($path),
        );
        return $name;
    }

    public function imageSize($name)
    {
        return array($this->images[$name]['w'], $this->images[$name]['h']);
    }

    public function image($name, $x, $y, $w, $h)
    {
        $this->cur .= sprintf("q %s 0 0 %s %s %s cm /%s Do Q\n",
            $this->n($w), $this->n($h), $this->n($x), $this->n($this->pageH - $y - $h), $name);
    }

    // ---------------------------------------------------------------- drawing
    private function n($v)
    {
        return rtrim(rtrim(sprintf('%.3f', $v), '0'), '.');
    }

    private function color($hex)
    {
        $hex = ltrim($hex, '#');
        return sprintf('%s %s %s',
            $this->n(hexdec(substr($hex, 0, 2)) / 255),
            $this->n(hexdec(substr($hex, 2, 2)) / 255),
            $this->n(hexdec(substr($hex, 4, 2)) / 255));
    }

    public function rect($x, $y, $w, $h, $fill = null)
    {
        $this->cur .= sprintf("%s rg %s %s %s %s re f\n", $this->color($fill),
            $this->n($x), $this->n($this->pageH - $y - $h), $this->n($w), $this->n($h));
    }

    /** Raw rect path appender used for batching many rects in one fill. */
    public function rects(array $rects, $fill)
    {
        $s = $this->color($fill) . " rg\n";
        foreach ($rects as $r) {
            $s .= sprintf("%s %s %s %s re\n", $this->n($r[0]), $this->n($this->pageH - $r[1] - $r[3]),
                $this->n($r[2]), $this->n($r[3]));
        }
        $this->cur .= $s . "f\n";
    }

    public function line($x1, $y1, $x2, $y2, $color, $width = 0.5)
    {
        $this->cur .= sprintf("%s RG %s w %s %s m %s %s l S\n", $this->color($color), $this->n($width),
            $this->n($x1), $this->n($this->pageH - $y1), $this->n($x2), $this->n($this->pageH - $y2));
    }

    /**
     * Rounded rectangle with individual corner radii.
     * $mode: 'f' fill, 'S' stroke, 'B' both.
     */
    public function roundRect($x, $y, $w, $h, $tl, $tr, $br, $bl, $mode, $fill = null, $stroke = null, $lw = 0.8)
    {
        $k = 0.5523;
        $H = $this->pageH;
        $X0 = $x;
        $X1 = $x + $w;
        $Yt = $H - $y;
        $Yb = $H - $y - $h;
        $p = '';
        if ($fill !== null) {
            $p .= $this->color($fill) . " rg\n";
        }
        if ($stroke !== null) {
            $p .= $this->color($stroke) . ' RG ' . $this->n($lw) . " w\n";
        }
        $p .= sprintf("%s %s m\n", $this->n($X0 + $tl), $this->n($Yt));
        $p .= sprintf("%s %s l\n", $this->n($X1 - $tr), $this->n($Yt));
        $p .= sprintf("%s %s %s %s %s %s c\n", $this->n($X1 - $tr + $tr * $k), $this->n($Yt),
            $this->n($X1), $this->n($Yt - $tr + $tr * $k), $this->n($X1), $this->n($Yt - $tr));
        $p .= sprintf("%s %s l\n", $this->n($X1), $this->n($Yb + $br));
        $p .= sprintf("%s %s %s %s %s %s c\n", $this->n($X1), $this->n($Yb + $br - $br * $k),
            $this->n($X1 - $br + $br * $k), $this->n($Yb), $this->n($X1 - $br), $this->n($Yb));
        $p .= sprintf("%s %s l\n", $this->n($X0 + $bl), $this->n($Yb));
        $p .= sprintf("%s %s %s %s %s %s c\n", $this->n($X0 + $bl - $bl * $k), $this->n($Yb),
            $this->n($X0), $this->n($Yb + $bl - $bl * $k), $this->n($X0), $this->n($Yb + $bl));
        $p .= sprintf("%s %s l\n", $this->n($X0), $this->n($Yt - $tl));
        $p .= sprintf("%s %s %s %s %s %s c\nh\n", $this->n($X0), $this->n($Yt - $tl + $tl * $k),
            $this->n($X0 + $tl - $tl * $k), $this->n($Yt), $this->n($X0 + $tl), $this->n($Yt));
        $p .= ($mode === 'B' ? 'B' : ($mode === 'S' ? 'S' : 'f')) . "\n";
        $this->cur .= $p;
    }

    // ------------------------------------------------------------------- text
    private function toWin1252($s)
    {
        if (function_exists('iconv')) {
            $r = @iconv('UTF-8', 'CP1252//TRANSLIT//IGNORE', $s);
            if ($r !== false) {
                return $r;
            }
        }
        return preg_replace('/[^\x20-\x7e]/', '?', $s);
    }

    public function textWidth($str, $size, $font = 'F1')
    {
        $str = $this->toWin1252($str);
        $w = 0;
        for ($i = 0, $l = strlen($str); $i < $l; $i++) {
            $c = ord($str[$i]);
            $w += ($c >= 32 && $c <= 126) ? self::$W[$font][$c - 32] : 556;
        }
        return $w * $size / 1000;
    }

    /** $y is the text baseline (from top). $align: L, C, R relative to $x. */
    public function text($x, $y, $str, $size, $font, $color, $align = 'L')
    {
        $w = $this->textWidth($str, $size, $font);
        if ($align === 'C') {
            $x -= $w / 2;
        } elseif ($align === 'R') {
            $x -= $w;
        }
        $enc = $this->toWin1252($str);
        $enc = str_replace(array('\\', '(', ')'), array('\\\\', '\\(', '\\)'), $enc);
        $this->cur .= sprintf("BT %s rg /%s %s Tf %s %s Td (%s) Tj ET\n", $this->color($color), $font,
            $this->n($size), $this->n($x), $this->n($this->pageH - $y), $enc);
    }

    // ----------------------------------------------------------------- output
    public function output()
    {
        $pages = $this->pages;
        $pages[] = $this->cur;
        $np = count($pages);

        $objs = array();
        // 1 catalog, 2 pages, 3 F1, 4 F2, then images, then page+content pairs
        $objs[1] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objs[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
        $objs[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
        $next = 5;
        $xobj = '';
        foreach ($this->images as $name => $im) {
            $cs = $im['ch'] == 1 ? '/DeviceGray' : ($im['ch'] == 4 ? '/DeviceCMYK' : '/DeviceRGB');
            $objs[$next] = array(
                sprintf("<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace %s /BitsPerComponent 8 /Filter /DCTDecode /Length %d >>",
                    $im['w'], $im['h'], $cs, strlen($im['data'])),
                $im['data'],
            );
            $xobj .= "/$name $next 0 R ";
            $next++;
        }
        $kids = array();
        $res = "<< /Font << /F1 3 0 R /F2 4 0 R >> /XObject << $xobj>> >>";
        $deflate = function_exists('gzcompress');
        foreach ($pages as $content) {
            $pageId = $next++;
            $contId = $next++;
            $kids[] = "$pageId 0 R";
            $objs[$pageId] = sprintf("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %s %s] /Resources %s /Contents %d 0 R >>",
                $this->n($this->pageW), $this->n($this->pageH), $res, $contId);
            if ($deflate) {
                $z = gzcompress($content, 6);
                $objs[$contId] = array(sprintf("<< /Filter /FlateDecode /Length %d >>", strlen($z)), $z);
            } else {
                $objs[$contId] = array(sprintf("<< /Length %d >>", strlen($content)), $content);
            }
        }
        $objs[2] = sprintf("<< /Type /Pages /Kids [%s] /Count %d >>", implode(' ', $kids), $np);

        ksort($objs);
        $out = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = array();
        foreach ($objs as $id => $o) {
            $offsets[$id] = strlen($out);
            if (is_array($o)) {
                $out .= "$id 0 obj\n{$o[0]}\nstream\n{$o[1]}\nendstream\nendobj\n";
            } else {
                $out .= "$id 0 obj\n$o\nendobj\n";
            }
        }
        $xref = strlen($out);
        $max = max(array_keys($objs));
        $out .= "xref\n0 " . ($max + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= $max; $i++) {
            $out .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $out .= "trailer\n<< /Size " . ($max + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n";
        return $out;
    }
}
