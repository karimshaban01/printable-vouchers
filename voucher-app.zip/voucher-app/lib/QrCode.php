<?php
/**
 * Minimal pure-PHP QR Code encoder (byte mode, error correction level M,
 * versions 1-6 => up to 106 bytes). No extensions or libraries required.
 * Compatible with PHP 5.6 / 7.x / 8.x.
 */
class QrCode
{
    // version => array(rawCodewords, blocks, eccPerBlock)  [level M]
    private static $VER = array(
        1 => array(26, 1, 10),
        2 => array(44, 1, 16),
        3 => array(70, 1, 26),
        4 => array(100, 2, 18),
        5 => array(134, 2, 24),
        6 => array(172, 4, 16),
    );
    private static $ALIGN = array(2 => 18, 3 => 22, 4 => 26, 5 => 30, 6 => 34);

    private static $exp = null;
    private static $log = null;

    /** @return array[] matrix[y][x] => bool (true = dark) */
    public static function encode($text)
    {
        self::initGf();
        $bytes = array_values(unpack('C*', (string)$text));
        $len = count($bytes);

        $version = 0;
        foreach (self::$VER as $v => $info) {
            $cap = $info[0] - $info[1] * $info[2];
            if (4 + 8 + 8 * $len <= $cap * 8) {
                $version = $v;
                break;
            }
        }
        if ($version === 0) {
            throw new Exception('Text too long for QR encoder (max 106 bytes).');
        }
        list($raw, $nBlocks, $ecLen) = self::$VER[$version];
        $dataCw = $raw - $nBlocks * $ecLen;

        // ---- bit stream
        $bits = '0100' . str_pad(decbin($len), 8, '0', STR_PAD_LEFT);
        foreach ($bytes as $b) {
            $bits .= str_pad(decbin($b), 8, '0', STR_PAD_LEFT);
        }
        $bits .= str_repeat('0', min(4, $dataCw * 8 - strlen($bits)));
        $bits .= str_repeat('0', (8 - strlen($bits) % 8) % 8);
        $data = array();
        for ($i = 0; $i < strlen($bits); $i += 8) {
            $data[] = bindec(substr($bits, $i, 8));
        }
        for ($pad = 0xEC; count($data) < $dataCw; $pad ^= 0xEC ^ 0x11) {
            $data[] = $pad;
        }

        // ---- split into blocks + Reed-Solomon
        $numShort = $nBlocks - $raw % $nBlocks;
        $shortLen = intdiv_compat($raw, $nBlocks);
        $gen = self::rsGenerator($ecLen);
        $dBlocks = array();
        $eBlocks = array();
        $pos = 0;
        for ($i = 0; $i < $nBlocks; $i++) {
            $dl = $shortLen - $ecLen + ($i < $numShort ? 0 : 1);
            $blk = array_slice($data, $pos, $dl);
            $pos += $dl;
            $dBlocks[] = $blk;
            $eBlocks[] = self::rsRemainder($blk, $gen);
        }
        $final = array();
        $maxD = $shortLen - $ecLen + 1;
        for ($i = 0; $i < $maxD; $i++) {
            foreach ($dBlocks as $blk) {
                if ($i < count($blk)) {
                    $final[] = $blk[$i];
                }
            }
        }
        for ($i = 0; $i < $ecLen; $i++) {
            foreach ($eBlocks as $blk) {
                $final[] = $blk[$i];
            }
        }

        // ---- matrix
        $size = $version * 4 + 17;
        $m = array_fill(0, $size, array_fill(0, $size, false));
        $fn = array_fill(0, $size, array_fill(0, $size, false));
        self::drawFunctionPatterns($m, $fn, $size, $version);

        // place data (zig-zag)
        $totalBits = count($final) * 8;
        $i = 0;
        for ($right = $size - 1; $right >= 1; $right -= 2) {
            if ($right == 6) {
                $right = 5;
            }
            for ($vert = 0; $vert < $size; $vert++) {
                for ($j = 0; $j < 2; $j++) {
                    $x = $right - $j;
                    $upward = (($right + 1) & 2) == 0;
                    $y = $upward ? $size - 1 - $vert : $vert;
                    if (!$fn[$y][$x] && $i < $totalBits) {
                        $m[$y][$x] = (($final[$i >> 3] >> (7 - ($i & 7))) & 1) == 1;
                        $i++;
                    }
                }
            }
        }

        // choose best mask
        $bestMask = 0;
        $bestPen = PHP_INT_MAX;
        for ($mask = 0; $mask < 8; $mask++) {
            $t = self::applyMask($m, $fn, $size, $mask);
            self::drawFormat($t, $size, $mask);
            $pen = self::penalty($t, $size);
            if ($pen < $bestPen) {
                $bestPen = $pen;
                $bestMask = $mask;
            }
        }
        $out = self::applyMask($m, $fn, $size, $bestMask);
        self::drawFormat($out, $size, $bestMask);
        return $out;
    }

    // ------------------------------------------------------------------ GF(256)
    private static function initGf()
    {
        if (self::$exp !== null) {
            return;
        }
        self::$exp = array_fill(0, 512, 0);
        self::$log = array_fill(0, 256, 0);
        $x = 1;
        for ($i = 0; $i < 255; $i++) {
            self::$exp[$i] = $x;
            self::$log[$x] = $i;
            $x <<= 1;
            if ($x & 0x100) {
                $x ^= 0x11D;
            }
        }
        for ($i = 255; $i < 512; $i++) {
            self::$exp[$i] = self::$exp[$i - 255];
        }
    }

    private static function mul($a, $b)
    {
        if ($a == 0 || $b == 0) {
            return 0;
        }
        return self::$exp[self::$log[$a] + self::$log[$b]];
    }

    private static function rsGenerator($degree)
    {
        $res = array_fill(0, $degree, 0);
        $res[$degree - 1] = 1;
        $root = 1;
        for ($i = 0; $i < $degree; $i++) {
            for ($j = 0; $j < $degree; $j++) {
                $res[$j] = self::mul($res[$j], $root);
                if ($j + 1 < $degree) {
                    $res[$j] ^= $res[$j + 1];
                }
            }
            $root = self::mul($root, 2);
        }
        return $res;
    }

    private static function rsRemainder($data, $gen)
    {
        $n = count($gen);
        $res = array_fill(0, $n, 0);
        foreach ($data as $b) {
            $factor = $b ^ array_shift($res);
            $res[] = 0;
            for ($i = 0; $i < $n; $i++) {
                $res[$i] ^= self::mul($gen[$i], $factor);
            }
        }
        return $res;
    }

    // ------------------------------------------------------- function patterns
    private static function setFn(&$m, &$fn, $x, $y, $dark)
    {
        $m[$y][$x] = $dark;
        $fn[$y][$x] = true;
    }

    private static function drawFunctionPatterns(&$m, &$fn, $size, $version)
    {
        // timing
        for ($i = 0; $i < $size; $i++) {
            self::setFn($m, $fn, 6, $i, $i % 2 == 0);
            self::setFn($m, $fn, $i, 6, $i % 2 == 0);
        }
        // finders (+ separators)
        self::finder($m, $fn, 3, 3, $size);
        self::finder($m, $fn, $size - 4, 3, $size);
        self::finder($m, $fn, 3, $size - 4, $size);
        // alignment (versions 2-6 have exactly one)
        if (isset(self::$ALIGN[$version])) {
            $c = self::$ALIGN[$version];
            for ($dy = -2; $dy <= 2; $dy++) {
                for ($dx = -2; $dx <= 2; $dx++) {
                    $d = max(abs($dx), abs($dy));
                    self::setFn($m, $fn, $c + $dx, $c + $dy, $d != 1);
                }
            }
        }
        // reserve format areas + dark module
        self::drawFormat($m, $size, 0, $fn);
    }

    private static function finder(&$m, &$fn, $cx, $cy, $size)
    {
        for ($dy = -4; $dy <= 4; $dy++) {
            for ($dx = -4; $dx <= 4; $dx++) {
                $d = max(abs($dx), abs($dy));
                $x = $cx + $dx;
                $y = $cy + $dy;
                if ($x >= 0 && $x < $size && $y >= 0 && $y < $size) {
                    self::setFn($m, $fn, $x, $y, $d != 2 && $d != 4);
                }
            }
        }
    }

    /** Draw format bits (level M). If $fn is given, also marks cells as function modules. */
    private static function drawFormat(&$m, $size, $mask, &$fn = null)
    {
        $data = (0 << 3) | $mask; // EC level M => 00
        $rem = $data;
        for ($i = 0; $i < 10; $i++) {
            $rem = ($rem << 1) ^ (($rem >> 9) * 0x537);
        }
        $bits = (($data << 10) | $rem) ^ 0x5412;
        $set = function ($x, $y, $dark) use (&$m, &$fn) {
            $m[$y][$x] = $dark;
            if ($fn !== null) {
                $fn[$y][$x] = true;
            }
        };
        $bit = function ($i) use ($bits) {
            return (($bits >> $i) & 1) != 0;
        };
        for ($i = 0; $i <= 5; $i++) {
            $set(8, $i, $bit($i));
        }
        $set(8, 7, $bit(6));
        $set(8, 8, $bit(7));
        $set(7, 8, $bit(8));
        for ($i = 9; $i < 15; $i++) {
            $set(14 - $i, 8, $bit($i));
        }
        for ($i = 0; $i < 8; $i++) {
            $set($size - 1 - $i, 8, $bit($i));
        }
        for ($i = 8; $i < 15; $i++) {
            $set(8, $size - 15 + $i, $bit($i));
        }
        $set(8, $size - 8, true);
    }

    // -------------------------------------------------------------- masking
    private static function applyMask($m, $fn, $size, $mask)
    {
        for ($y = 0; $y < $size; $y++) {
            for ($x = 0; $x < $size; $x++) {
                if ($fn[$y][$x]) {
                    continue;
                }
                switch ($mask) {
                    case 0: $inv = ($x + $y) % 2 == 0; break;
                    case 1: $inv = $y % 2 == 0; break;
                    case 2: $inv = $x % 3 == 0; break;
                    case 3: $inv = ($x + $y) % 3 == 0; break;
                    case 4: $inv = (intdiv_compat($x, 3) + intdiv_compat($y, 2)) % 2 == 0; break;
                    case 5: $inv = ($x * $y) % 2 + ($x * $y) % 3 == 0; break;
                    case 6: $inv = (($x * $y) % 2 + ($x * $y) % 3) % 2 == 0; break;
                    default: $inv = (($x + $y) % 2 + ($x * $y) % 3) % 2 == 0; break;
                }
                if ($inv) {
                    $m[$y][$x] = !$m[$y][$x];
                }
            }
        }
        return $m;
    }

    private static function penalty($m, $size)
    {
        $p = 0;
        $rows = array();
        $cols = array_fill(0, $size, '');
        for ($y = 0; $y < $size; $y++) {
            $row = '';
            for ($x = 0; $x < $size; $x++) {
                $c = $m[$y][$x] ? '1' : '0';
                $row .= $c;
                $cols[$x] .= $c;
            }
            $rows[] = $row;
        }
        $lines = array_merge($rows, $cols);
        foreach ($lines as $s) {
            // N1: runs
            $run = 1;
            for ($i = 1; $i <= $size; $i++) {
                if ($i < $size && $s[$i] === $s[$i - 1]) {
                    $run++;
                } else {
                    if ($run >= 5) {
                        $p += 3 + ($run - 5);
                    }
                    $run = 1;
                }
            }
            // N3: finder-like patterns
            foreach (array('10111010000', '00001011101') as $pat) {
                $off = 0;
                while (($f = strpos($s, $pat, $off)) !== false) {
                    $p += 40;
                    $off = $f + 1;
                }
            }
        }
        // N2: 2x2 blocks
        for ($y = 0; $y < $size - 1; $y++) {
            for ($x = 0; $x < $size - 1; $x++) {
                $c = $m[$y][$x];
                if ($c === $m[$y][$x + 1] && $c === $m[$y + 1][$x] && $c === $m[$y + 1][$x + 1]) {
                    $p += 3;
                }
            }
        }
        // N4: balance
        $dark = 0;
        foreach ($m as $row) {
            foreach ($row as $c) {
                if ($c) {
                    $dark++;
                }
            }
        }
        $pct = $dark * 100 / ($size * $size);
        $p += 10 * (int)floor(abs($pct - 50) / 5);
        return $p;
    }
}

if (!function_exists('intdiv_compat')) {
    function intdiv_compat($a, $b)
    {
        return (int)floor($a / $b);
    }
}
