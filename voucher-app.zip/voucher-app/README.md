# Wi-Fi Voucher PDF Generator (PHP 7+)

Upload one or many voucher `.csv` files -> get **one sample PDF per CSV**
(A4, 10 vouchers per page, QR code + code + customer-service details).

No Composer, no libraries: includes its own QR encoder and PDF writer.

## Requirements
- PHP 7.0+ (tested on 8.3; code avoids 7.4+/8 syntax)
- Optional: `zip` extension (for "Download all .zip"), `iconv` (accents in text)
- Web server user must be able to write to `storage/jobs/`

## Run locally
    php -S 127.0.0.1:8080
    # open http://127.0.0.1:8080/index.php

## Deploy (Apache/Nginx)
Copy the folder to your web root. `storage/` is blocked via `.htaccess`
(Apache); on Nginx add:  `location ^~ /storage/ { deny all; }`
PDFs are only served through `download.php`.

## CSV format
One code per line (first column). Lines starting with `#` are ignored
(roll metadata), blank lines skipped. Example: `"FkRbzGHAWGF"`.

## Files
- `index.php`       upload form, processing, results page
- `download.php`    safe PDF / ZIP download (strict id + filename validation)
- `config.php`      limits and defaults (files, size, count, phone numbers, TTL)
- `lib/QrCode.php`  QR encoder (byte mode, ECC M, up to 106 bytes)
- `lib/MiniPdf.php` minimal PDF writer
- `lib/VoucherPdf.php` card layout (edit colors/text/sizes here)
- `lib/CsvReader.php`  tolerant CSV reader
- `assets/logo.jpg` header logo (replace with your own JPEG)

Generated PDFs are deleted automatically after 24 hours (`job_ttl_seconds`).
