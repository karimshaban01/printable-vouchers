<?php
// ---- Voucher system settings -------------------------------------------------
return array(
    'max_files'        => 20,                 // CSV files per upload
    'max_file_bytes'   => 5 * 1024 * 1024,    // 5 MB per CSV
    'default_count'    => 10,                 // sample vouchers per PDF (10 = one A4 page)
    'max_count'        => 2000,               // upper bound when the user asks for more
    'job_ttl_seconds'  => 86400,              // generated PDFs are deleted after 24h
    'storage_dir'      => __DIR__ . '/storage/jobs',
    'logo'             => __DIR__ . '/assets/logo.jpg',

    // defaults shown in the form (editable per upload)
    'support_name'     => 'KARIM',
    'support_phones'   => '0628370174 | 0785817222',
);
